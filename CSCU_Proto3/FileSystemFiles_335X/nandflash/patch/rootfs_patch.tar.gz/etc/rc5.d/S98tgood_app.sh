#!/bin/sh

# The startup entry of TGOOD applications

echo "------------------- /etc/rc5.d/tgood_app.sh Start ----------------------"

### INIT ###
# Set environment
source /etc/profile.d/set_env.sh
# Init the board (Don't run this script in background!)
/mnt/nandflash/sbin/board/board_init.sh
# Start watchdog timer and lcd_heater
/mnt/nandflash/sbin/guardian/guardian.sh &


### RUN APP ###
# Board-test mode
factest=`awk -F "factest=" '{print $2}' /proc/cmdline`
if [ "$factest" = "Y" ]; then
    dd if=/dev/zero of=/dev/fb0 bs=1600 count=600  # Clear the screen
    echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t  BOARD TEST MODE" > /dev/tty0
    /mnt/nandflash/sbin/modbus/modbus_server &
    exit
fi
# Normal mode
# Touchscreen calibration
cali=`awk -F "calibrate=| laohua" '{print $2}' /proc/cmdline`
if [ "$cali" = "Y" ]; then
    if [ ! -e /etc/pointercal ]; then
        /usr/bin/ts_calibrate 
        sync
    fi
fi
# Run user APPs
/mnt/nandflash/user.sh &


### SHOW VERSION ###
# Show hardware & kernel version
cat /proc/version_tgood
# Show filesystem version
cat /etc/version_tgood
# Show APP version
# cat /mnt/nandflash/version_tgood

echo "------------------- /etc/rc5.d/tgood_app.sh End ------------------------"

