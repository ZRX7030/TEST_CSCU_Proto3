#!/bin/sh

# Set QT environment variables

#echo "------------------- /etc/profile.d/set_env.sh Start ---------------------"

# --- Basic config
#export BOARDNAME=`cat /proc/boardname`
export PATH="/usr/local/bin:/usr/bin:/bin"
export PATH=$PATH:/usr/local/sbin:/usr/sbin:/sbin
export PATH=$PATH:`find /mnt/nandflash/sbin/ -type d | tr '\n' ':'`

# --- tslib config
export TSLIB_TSDEVICE=/dev/input/touchscreen0
export TSLIB_CONFFILE=/etc/ts.conf
export TSLIB_PLUGINDIR=/usr/lib/ts
export POINTERCAL_FILE=/etc/pointercal
export TSLIB_CALIBFILE=/etc/pointercal
export TSLIB_CONSOLEDEVICE=none
export TSLIB_FBDEVICE=/dev/fb0

# --- qteverywhere config
export QTDIR=/opt/QT4.8.6
export LD_LIBRARY_PATH=$QTDIR/lib
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$QTDIR/plugins
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$QTDIR/plugins/imageformats
export QT_QWS_FONTDIR=$QTDIR/lib/fonts

# --- Other environment variables
#export QWS_DISPLAY=LinuxFb:/dev/fb0
export QWS_DISPLAY=transformed:rot180:linuxfb:0
#export KEYPAD_DEV=/dev/input/keypad
#export QWS_KEYBOARD="USB:/dev/input/usbkbd"

export QT_APP_PATH=/mnt/nandflash
export QT_BIN_PATH=$QT_APP_PATH/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$QT_APP_PATH/lib
export PATH=$PATH:$QT_APP_PATH
export PATH=$PATH:$QT_BIN_PATH

# --- Screen Size
export FB_SIZE=$(cat /sys/class/graphics/fb0/virtual_size)
if [ $FB_SIZE = "1024,1536" ]; then
  export QWS_SIZE="1024x768"
else
  export QWS_SIZE="800x600"
fi

# --- Touchscreen or Mouce
export TYPE=`cat /etc/t2m`
if [ $TYPE = "T" ]; then
  export QWS_MOUSE_PROTO="Tslib:/dev/input/touchscreen0"
else
  export QWS_MOUSE_PROTO="Intellimouse:/dev/input/mice"
fi

#echo "------------------- /etc/profile.d/set_env.sh End -----------------------"
