#!/bin/sh

# The startup entry of TGOOD applications

echo "------------------- /etc/rc3.d/S98tgood_boardtesthelper.sh Start ----------------------"

### INIT ###
# Set environment
source /etc/profile.d/set_env.sh
# Init the board (Don't run this script in background!)
/mnt/nandflash/sbin/board/board_init.sh
# Start watchdog timer and lcd_heater
/mnt/nandflash/sbin/guardian/guardian.sh &


### RUN APP ###
# Board test helper mode
dd if=/dev/zero of=/dev/fb0 bs=1600 count=600  # Clear the screen
echo -e "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\tBOARD TEST HELPER MODE" > /dev/tty0
/mnt/nandflash/sbin/board/test_board_server.sh &


### SHOW VERSION ###
# Show hardware & kernel version
cat /proc/version_tgood
# Show filesystem version
cat /etc/version_tgood
# Show APP version
# cat /mnt/nandflash/version_tgood

echo "------------------- /etc/rc3.d/S98tgood_boardtesthelper.sh End ------------------------"

